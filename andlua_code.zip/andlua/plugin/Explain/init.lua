--插件名称
PluginName="插件说明"

--插件作者
Author="AndLua+"

--插件版本
Edition="1.0"

--是否自启动
AutoStart=false